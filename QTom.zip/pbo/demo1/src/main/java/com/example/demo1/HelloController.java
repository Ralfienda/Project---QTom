package com.example.demo1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.input.MouseEvent;

import java.io.File;
import java.io.IOException;

public class HelloController {

   private Stage stage;
   private Scene scene;
   private Parent root;

   @FXML
   private Button logoutButton;
   @FXML
   private AnchorPane scenePane;
    @FXML
    private Button backloginButton;

    @FXML
    private Button chooseMusic;

    private MediaPlayer mediaPlayer;

    @FXML
    private Button createquizButton;

    @FXML
    private Button quizlistButton;

    @FXML
    void chooseMusic(MouseEvent event) {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Select Your Music");
        File file = chooser.showOpenDialog(null);
        if(file != null){
            String selectedFile = file.toURI().toString();
            Media media = new Media(selectedFile);
            mediaPlayer = new MediaPlayer(media);
            mediaPlayer.setOnReady(() -> chooseMusic.setText(file.getName()));

        }

    }

    @FXML
    void pause(MouseEvent event) {
        mediaPlayer.pause();


    }

    @FXML
    void play(MouseEvent event) {
        mediaPlayer.play();

    }

    @FXML
    void stop(MouseEvent event) {
        mediaPlayer.stop();

    }



    Stage layar;
   public void logout(ActionEvent event){

       Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
       alert.setTitle("Logout");
       alert.setHeaderText("You're about to logout!");
       alert.setContentText("Are you sure?: ");

       if (alert.showAndWait().get() == ButtonType.OK) {
           stage = (Stage) scenePane.getScene().getWindow();
           System.out.println("You Succesfully Logged Out!");
           stage.close();
       }

   }



   public void swtichToScene1(ActionEvent event) throws IOException {
       Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
       stage = (Stage)((Node)event.getSource()).getScene().getWindow();
       scene = new Scene(root);
       stage.setScene(scene);
       stage.show();

   }

   public void swtichToScene2(ActionEvent event) throws IOException {
       Parent root = FXMLLoader.load(getClass().getResource("Scene2.fxml"));
       stage = (Stage)((Node)event.getSource()).getScene().getWindow();
       scene = new Scene(root);
       stage.setScene(scene);
       stage.show();

   }
    public void swtichToScene3(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene3.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }
}